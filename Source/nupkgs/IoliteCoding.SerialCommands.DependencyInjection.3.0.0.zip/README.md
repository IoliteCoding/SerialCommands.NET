# IolitteCoding.SerialCommands.DependencyInjection

This lirary contains the extention functions for the SerialCommands library to be used with Dependency Injection.